<?php
$imagePath = theme_path("images/login");
?>
<div id="footer" >
    <div>
    <?php include_partial('global/copyright'); ?>
    </div>
    <div id="social-icons">
        <a href="http://www.linkedin.com/groups?home=&amp;gid=891077" target="_blank">
            <img src="<?php echo "{$imagePath}/linkedin.png"; ?>" alt="LinkedIn OrangeHRM group"/></a>&nbsp;
        <a href="http://www.facebook.com/OrangeHRM" target="_blank">
            <img src="<?php echo "{$imagePath}/facebook.png"; ?>" alt="OrangeHRM on Facebook"/></a>&nbsp;
        <a href="http://twitter.com/orangehrm" target="_blank">
            <img src="<?php echo "{$imagePath}/twiter.png"; ?>" alt="OrangeHRM on twitter"/></a>&nbsp;
        <a href="http://www.youtube.com/orangehrm" target="_blank">
            <img src="<?php echo "{$imagePath}/youtube.png"; ?>" alt="OrangeHRM on youtube"/></a>&nbsp;
    </div>
</div>
