<?php

/**
 * EmployeeStatus form.
 *
 * @package    form
 * @subpackage EmployeeStatus
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class EmployeeStatusForm extends BaseEmployeeStatusForm
{
  public function configure()
  {
  }
}